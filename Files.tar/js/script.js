function BeforeEnter()
{
    alert("Добро пожаловать")
}
// function odin(value)
// {
//     var text = document.getElementsById("name-input");
//     var val2 = text.value;
// }
// function dva(value)
// {
//     var number = document.getElementsById("second-call");
//     var val1 = number.value;
// }
function ButtonClickCall()
{
    alert("Мы перезвоним Вам!")
}
function ButtonClickEmail()
{
    alert("Вам на почту был отправлен код подтверждения")
}

function Img_Alert()
{
    alert("Картинка")
}

